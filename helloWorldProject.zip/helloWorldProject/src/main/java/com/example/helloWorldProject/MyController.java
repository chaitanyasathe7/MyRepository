package com.example.helloWorldProject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
     
	//======Hello World Demo
	/*@RequestMapping(value="/hello",method=RequestMethod.GET)
	public String Mymethod()
   {
		return "Hello World!!!";
   }*/
	
	
	//==========env specific properties file demo
	
	@Value("${employee.name}")
	private String userName;
	
	@RequestMapping(value="invite",method=RequestMethod.GET)
	public String getInvitation() {
		
		return "Hi "+userName +" Welcome" ;
	}
	
}
	
